

<?php $__env->startSection('content'); ?>

<p class="mb-3" style="font-size:24px; font-weight:600"> <i class="fa fa-btc"></i> Buy Ticket</p>

<div class="row">
    <div class="col-md-6 mb-md-0 mb-4">
        <div class="w-100 h-100 p-4 shadow-sm text-uppercase bg-white">
            <div style="font-size: 40px; font-weight:700; color: darkred;"> <?php echo e($ticket->lottory); ?> </div>
            <div style="font-size: 25px; font-weight:500"> JACKPOT: $ <?php echo e($ticket->jackpot); ?> </div>
            <div style="font-size: 25px; font-weight:500"> PRICE: $ <?php echo e($ticket->price); ?> </div>
            <div style="font-size: 16px; color: red;">
                *Kindly note that you must have PAID <?php echo e(round($ticket->price / $btcCurrentPrice,6)); ?> into the blockchain address before clicking the Pay button.*
            </div> 
            <div class="mt-3">
                <p class="text-primary">BTC Wallet: <b> ad;lfkaldfkadlkfadklfalkdfaldflkadflkadfakl </b> </p>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-danger"> <?php echo e($error); ?> </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <form action="<?php echo e(url('user/purchase-tick')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label>Payment Proof</label>
                    <input type="hidden" name="lottery" value="<?php echo e($ticket->lottory); ?>">
                    <input type="hidden" name="price" value="<?php echo e($ticket->price); ?>">
                    <input type="hidden" name="jackpot" value="<?php echo e($ticket->jackpot); ?>">
                    <input type="file" required name="receipt" class="form-control rounded-pill" style="height: 40px;">
                    <button class="btn btn-primary rounded-pill mt-3 form-control" style="height: 50px;">BUY</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="w-100 mb-3 shadow-sm bg-white">
            <img src="<?php echo e(url('img/lottory.webp')); ?>" width="100%" alt="">
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/user/buy-ticket.blade.php ENDPATH**/ ?>