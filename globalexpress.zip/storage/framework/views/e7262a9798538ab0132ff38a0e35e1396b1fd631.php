

<?php $__env->startSection('content'); ?>

<h4> <?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?> Withdraws </h4>

<div class="responsive-table mt-3">
    <table style="font-size:16px" class="table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Ammount To Withdraw </th>
                <th>BTC Worth</th>
                <th>Wallet To Credit</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $member->withdraws()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($withdraw->created_at); ?> </td>
                    <td> <?php echo e($withdraw->amount_to_withdraw); ?> </td>
                    <td> <?php echo e($withdraw->btc_worth); ?> </td>
                    <td> <?php echo e($withdraw->bitcoin_wallet_to_credit); ?> </td>
                    <td> <?php echo e($withdraw->status); ?> </td>
                    <td> <a href="<?php echo e(url('admin/edit-withdraw/' . $withdraw->id)); ?>" class="btn btn-primary"> Edit </a> </td>
                    <td> <a href="<?php echo e(url('admin/delete-withdraw/' . $withdraw->id)); ?>" class="btn btn-danger"> Delete </a> </td>    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/withdraw.blade.php ENDPATH**/ ?>