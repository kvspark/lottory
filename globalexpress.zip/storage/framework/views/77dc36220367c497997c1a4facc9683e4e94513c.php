

<?php $__env->startSection('content'); ?>

<p class="mb-3" style="font-size:24px; font-weight:600"> <i class="fa fa-arrow-down"></i> Withdraw</p>

<div class="table-responsive mt-3">
    <table class="table">
        <thead>
            <tr>
                <th>Amount</td>
                <th>BTC Worth</td>
                <th>Wallet To Credit</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user->withdraws()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($withdraw->amount_to_withdraw); ?></td>
                    <td> <?php echo e($withdraw->bitcoin_worth); ?> </td>
                    <td> <?php echo e($withdraw->bitcoin_wallet_to_credit); ?> </td>
                    <td> <?php echo e($withdraw->status); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/user/my-withdraw.blade.php ENDPATH**/ ?>