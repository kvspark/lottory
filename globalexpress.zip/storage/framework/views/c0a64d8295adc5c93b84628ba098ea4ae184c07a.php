

<?php $__env->startSection('content'); ?>

<h4> Create Winning Number </h4>
<?php if(Session::has('successful')): ?>
    <div class="alert alert-success"> <?php echo e(Session::get('successful')); ?> </div>
<?php endif; ?>
<div class="mt-3">
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"> <?php echo e($error); ?> </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>                

    <form action="<?php echo e(url('admin/post-edit-winning')); ?>/<?php echo e($win->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label class="mb-0">Lottery Name</label>
        <select required name="lottery_name" style="height: 50px;" class="form-control mb-3 shadow-none">
            <option> <?php echo e($win->lottery_name); ?> </option>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ticket->lottory); ?>"> <?php echo e($ticket->lottory); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label class="mb-0">Date</label>
        <div class="input-group">
            <input required value="<?php echo e($win->created_at); ?>" type="text" name="date" style="height: 50px;" class="form-control mb-3 shadow-none">
        </div>
        <label class="mb-0">Next Jackpot</label>
        <input required type="number" value="<?php echo e($win->next_jackpot); ?>" name="next_jackpot" style="height: 50px;" class="form-control mb-3 shadow-none">
        <button class="btn btn-primary" style="height: 50px;">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/edit-winning.blade.php ENDPATH**/ ?>