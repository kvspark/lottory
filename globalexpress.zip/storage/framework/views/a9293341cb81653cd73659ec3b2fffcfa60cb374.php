

<?php $__env->startSection('content'); ?>

<h4>All Users</h4>

<div class="table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Edit</th>
                <th> Bet </th>
                <th> Withdraw </th>
                <th> Delete </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?> </td>
                    <td> <?php echo e($member->email_address); ?> </td>
                    <td> <a href="../admin/edit-member/<?php echo e($member->id); ?>" class="btn btn-primary"> Edit </a> </td>
                    <td> <a href="../admin/placed-bet/<?php echo e($member->id); ?>" class="btn btn-secondary"> Bets </a> </td>
                    <td> <a href="../admin/withdraw/<?php echo e($member->id); ?>" class="btn btn-warning"> Withdraws </a> </td>
                    <td> <a href="../admin/delete-member/<?php echo e($member->id); ?>" class="btn btn-danger"> Delete </a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/member.blade.php ENDPATH**/ ?>