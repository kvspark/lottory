

<?php $__env->startSection('content'); ?>

<h4>Dashboard</h4>

<div class="mt-3 row">
    <div class="col-md-6 mb-3">
        <div class="w-100 p-3 bg-dark text-white">
            <h4 class="text-uppercase">Members</h4>
            <p> Total Members <?php echo e($members->count()); ?> </p>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="w-100 p-3 bg-success text-white">
            <h4 class="text-uppercase">Pending Withdraws</h4>
            <p> Total Withdraws <?php echo e($withdraws->where('status','Proccessing')->count()); ?> </p>
        </div>
    </div>
</div>
<div class="mt-3 row">
    <div class="col-md-6 mb-3">
        <div class="w-100 p-3 bg-primary text-white">
            <h4 class="text-uppercase">Purchase Ticket</h4>
            <p> Total Purchase Ticket <?php echo e($purchasetickets->count()); ?> </p>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="w-100 p-3 bg-warning text-white">
            <h4 class="text-uppercase">Pending Ticket</h4>
            <p> Total Wins <?php echo e($purchasetickets->where('status','Pending')->count()); ?> </p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>