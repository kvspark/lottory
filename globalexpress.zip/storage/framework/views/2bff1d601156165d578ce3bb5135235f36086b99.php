

<?php $__env->startSection('content'); ?>

<h4>All Tickets</h4>

<div class="table-reponsive">
    <table class="table">
        <thead>
            <tr>
                <th>Lottery Name</th>
                <th>Winning Number</th>
                <th> Next Jackpot </th>
                <th> Date </th>
                <th> Edit </th>
                <th> Delete </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $winnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $winning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($winning->lottery_name); ?> </td>
                    <td class="d-flex"> 
                        <?php    
                            $win = $winning->winning_number;
                            $wins = preg_split('/ /',$win);
                        ?>
                        <?php $__currentLoopData = $wins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> <?php echo e($w); ?> </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td> $<?php echo e(number_format($winning->next_jackpot,2)); ?> </td>
                    <td> <?php echo e($winning->created_at); ?> </td>
                    <td> <a href="<?php echo e(url('admin/edit-winning')); ?>/<?php echo e($winning->id); ?>" class="btn btn-primary"> Edit </a> </td>
                    <td> <a href="<?php echo e(url('admin/delete-winning')); ?>/<?php echo e($winning->id); ?>" class="btn btn-danger"> Delete </a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/winning.blade.php ENDPATH**/ ?>