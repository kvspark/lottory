
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from Global Express Lotto.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 27 Sep 2023 12:59:35 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    
    <title>Welcome - Global Express Lotto</title>
    <!-- site favicon -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <!-- site favicon -->
     <link rel="shortcut icon" type="image/png" href="User/assets/images/head.png">
    <link rel="shortcut icon" type="image/png" href="User/assets/images/head.png">
    <!-- fontawesome css link -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- bootstrap css link -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- animate css link -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- lightcase css link -->
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <!-- slick css link -->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!-- swiper css link -->
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <!-- flipclock css link -->
    <link rel="stylesheet" href="assets/css/flipclock.css">
    <!-- jqvmap css link -->
    <link rel="stylesheet" href="assets/css/jqvmap.min.css">
    <!-- main style css link -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- responsive css link -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <meta name="keywords" content="Online Lottery,Live Lotter,Poolmond,Mega Pool Lotto Lottery,USA and UK National Lottery,Official USA and UK National Lottery Website,UK National Lottery Website,2021 USA Lottery">
    <link href="../cdn.jsdelivr.net/npm/bootstrap%405.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="../cdn.jsdelivr.net/npm/bootstrap%405.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script></head>
<body>

  <!-- preloader start -->
  <div id="preloader"></div>
  

  <div class="main-light-version">
    
    <?php echo $__env->make('component.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--login registration Modal -->
    			
<div class="modal fade login-registration-modal" id="exampleModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-body">
          <div class="login-registration-area">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="login-tab" data-toggle="tab" href="#login" role="tab" aria-controls="login" aria-selected="true">Login</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="registration-tab" data-toggle="tab" href="#registration" role="tab" aria-controls="registration" aria-selected="false">Registration</a>
              </li>
            </ul>
            <div class="tab-content" id="myTabContent">
              <div class="tab-pane fade show active" id="login" role="tabpanel" aria-labelledby="login-tab">
                <form class="login-form cmn-frm" method="post">
                  <div class="frm-group">
                    <label>Username or Email Address</label>
                    <input type="email" name="UserName1" id="login_email" placeholder="Username or Email Address">
                    <i class="fa fa-user"></i>
                  </div>
                  <div class="frm-group">
                    <label>Password</label>
                    <input type="password" name="password" id="login_pass" placeholder="Enter Password">
                    <i class="fa fa-lock"></i>
                  </div>
                  <div class="frm-group">
                    <input type="submit" name="btnlogin" id="Button" value="login">
                  </div>
                  <div class="frm-group">
                    <div class="checkbox-area">
                      <input type="checkbox" id="login_remember_pass">
                      <label for="login_remember_pass">Remember Password</label>
                    </div>
                    <div class="forgot-pass-area">
                      <a href="#0">Forgot Password?</a>
                    </div>
                  </div>
                  <div class="frm-group">
                    <div class="or-text">
                      <span>Or login with</span>
                    </div>
                  </div>
                  <div class="frm-group">
                    <div class="login-with-area">
                      <a href="#" class="facebook"><i class="fa fa-facebook-f"></i>facebook</a>
                      <a href="#" class="google"><i class="fa fa-google-plus"></i>facebook</a>
                      <a href="#" class="twitter"><i class="fa fa-twitter"></i>facebook</a>
                    </div>
                  </div>
                </form>
                <div class="have-not-account">
                  <p>You don’t have an account?<a href="#0">Register Now</a></p>
                </div>
              </div>
              <div class="tab-pane fade" id="registration" role="tabpanel" aria-labelledby="registration-tab">
                <form class="registration-form cmn-frm">
                  <div class="frm-group">
                    <label>Username or Email Address</label>
                    <input type="email" name="registration_email" id="registration_email" placeholder="Username or Email Address">
                    <i class="fa fa-user"></i>
                  </div>
                  <div class="frm-group">
                    <label>Password</label>
                    <input type="password" name="registration_pass" id="registration_pass" placeholder="Enter Password">
                    <i class="fa fa-lock"></i>
                  </div>
                  <div class="frm-group">
                    <label>Confirm Password</label>
                    <input type="password" name="registration_re_pass" id="registration_re_pass" placeholder="Enter Password">
                    <i class="fa fa-lock"></i>
                  </div>
                  <div class="frm-group">
                    <input type="submit" name="registration_submit" id="registration_submit" value="Registration">
                  </div>
                  <div class="frm-group">
                    <div class="checkbox-area">
                      <input type="checkbox" id="registration_remember_pass">
                      <label for="registration_remember_pass">I Agree with the Terms of Use</label>
                    </div>
                    <div class="forgot-pass-area">
                      <a href="#0">Forgot Password?</a>
                    </div>
                  </div>
                  <div class="frm-group">
                    <div class="or-text">
                      <span>Or login with</span>
                    </div>
                  </div>
                  <div class="frm-group">
                    <div class="login-with-area">
                      <a href="#" class="facebook"><i class="fa fa-facebook-f"></i>facebook</a>
                      <a href="#" class="google"><i class="fa fa-google-plus"></i>facebook</a>
                      <a href="#" class="twitter"><i class="fa fa-twitter"></i>facebook</a>
                    </div>
                  </div>
                </form>
                <div class="have-not-account">
                  <p>Already have an account?<a href="#0">Login</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>    
    <!-- banner-section start -->
    <section class="banner-section">
        
      <div class="banner-elements-part has_bg_image" data-background="assets/images/elements/vector-bg.jpg">
          <div class="element-one"><img src="assets/images/elements/box.png" alt="vector-image"></div>

          <div class="element-two"><img src="assets/images/elements/car.png" alt="vector-image"></div>

          <div class="element-three"><img src="assets/images/elements/chart.png" alt="vector-image"></div>

          <div class="element-four"><img src="assets/images/elements/dollars.png" alt="vector-image"></div>

          <div class="element-five"><img src="assets/images/elements/laptop.png" alt="vector-image"></div>

          <div class="element-six"><img src="assets/images/elements/money-2.png" alt="vector-image"></div>

          <div class="element-seven"><img src="assets/images/elements/person.png" alt="vector-image"></div>

          <div class="element-eight"><img src="assets/images/elements/person-2.png" alt="vector-image"></div>

          <div class="element-nine"><img src="assets/images/elements/power.png" alt="vector-image"></div>
      </div>
      <div class="banner-content-area">
          <div class="container">
              <div class="row">
                  <div class="col-md-6">
                      <div class="banner-content">
                          <h1 class="title">Take the chance to change your life</h1>
                          <p>Global Express Lotto is an online lottery platform inspired by few Global Express Lotto lover's fantasy of the ultimate lottery platfrom.</p>
                          <a href="lottery-2" class="cmn-btn">buy ticket now !</a>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
    <!-- banner-section end -->

    

    <!-- jackpot-section start -->
    <section class="jackpot-section section-padding">
      <div class="container">

        <div class="row justify-content-center">
          <div class="col-lg-5">
            <div class="section-header text-center">
              <h2 class="section-title">Lottery Jackpots</h2>
              <p>Choose from the Powerball, Mega Millions, Lotto or Lucky Day Lotto and try for a chance to win a big cash prize</p>
            </div>
          </div>
        </div>
        <div class="row">
                            <div class="col-lg-4 col-md-6">
            <div class="jackpot-item text-center">
              <img src="assets/images/elements/jackpot-3.png" alt="image">
              <span class="amount">Euro Jackpots</span>
              <h5 class="title">35,442,000</h5>
              <!-- <p class="next-draw-time">Next Draw : <span id="remainTime1"></span></p>
              <a href="#0" class="cmn-btn">play now!</a> -->
            </div>
          </div>
                    <div class="col-lg-4 col-md-6">
            <div class="jackpot-item text-center">
              <img src="assets/images/elements/jackpot-2.png" alt="image">
              <span class="amount">Cancer Charity</span>
              <h5 class="title">13,287,000</h5>
              <!-- <p class="next-draw-time">Next Draw : <span id="remainTime1"></span></p>
              <a href="#0" class="cmn-btn">play now!</a> -->
            </div>
          </div>
                    <div class="col-lg-4 col-md-6">
            <div class="jackpot-item text-center">
              <img src="assets/images/elements/jackpot-4.png" alt="image">
              <span class="amount">US Powerball
</span>
              <h5 class="title">161,557,581</h5>
              <!-- <p class="next-draw-time">Next Draw : <span id="remainTime1"></span></p>
              <a href="#0" class="cmn-btn">play now!</a> -->
            </div>
          </div>
                    <div class="col-lg-4 col-md-6">
            <div class="jackpot-item text-center">
              <img src="assets/images/elements/jackpot-1.png" alt="image">
              <span class="amount">Mega Millions</span>
              <h5 class="title">25,000,000</h5>
              <!-- <p class="next-draw-time">Next Draw : <span id="remainTime1"></span></p>
              <a href="#0" class="cmn-btn">play now!</a> -->
            </div>
          </div>
           
          <!-- jackpot-item end -->
          <!-- <div class="col-lg-4 col-md-6">
            <div class="jackpot-item text-center">
              <img src="assets/images/elements/jackpot-2.png" alt="image">
              <span class="amount">€161,557,581</span>
              <h5 class="title">Cancer Charity</h5>
              <p class="next-draw-time">Next Draw : <span id="remainTime2"></span></p>
              <a href="#0" class="cmn-btn">play now!</a>
            </div>
          </div> -->
          <!-- jackpot-item end -->
          <!-- <div class="col-lg-4 col-md-6">
            <div class="jackpot-item text-center">
              <img src="assets/images/elements/jackpot-3.png" alt="image">
              <span class="amount">€161,557,581</span>
              <h5 class="title">EuroJackpot</h5>
              <p class="next-draw-time">Next Draw : <span id="remainTime3"></span></p>
              <a href="#0" class="cmn-btn">play now!</a>
            </div>
          </div> -->
          <!-- jackpot-item end -->
          <div class="col-lg-12 text-center">
            <a href="lottery" class="text-btn">Show all lotteries</a>
          </div>
        </div>
      </div>
    </section>


    <!-- lottery-timer-section start -->
    <section class="lottery-timer-section">
      <div class="container">
        <div class="row justify-content-between">
          <div class="col-xl-6">
            <div class="timer-content">
              <h3 class="title">Buy Lottery Tickets Online</h3>
              <p>Buy lottery tickets online to the biggest lotteries in the world offering huge jackpot prizes that you can win when you play online lottery.</p>
            </div>
          </div>
          <!-- <div class="col-xl-5 text-center">
            <div class="timer-part">
              <div class="clock"></div>
            </div>
          </div> -->
          <div class="col-xl-6">
            <div class="link-area text-center">
            
                <!-- <button type="button" class="cmn-btn" data-toggle="modal" data-target="#exampleModal">register & play</button></br> -->
              
              <!-- <a href="#0" class="border-btn">register & play</a> -->
              <a href="lottery" class="text-btn">view all offer</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- lottery-timer-section end -->
    <!-- jackpot-section start -->

    <!-- lottery-result-section start -->
    <section class="lottery-result-section section-padding has_bg_image" data-background="assets/images/bg-one.jpg">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-7">
            <div class="section-header text-center">
              <h2 class="section-title">Latest Lottery Results</h2>
              <p>Check your lotto results online, find all the lotto winning numbers and see if you won the latest lotto jackpots! </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-8">
            <div class="lottery-winning-num-part">
              <div class="lottery-winning-num-table">
                <h3 class="block-title">lottery winning numbers</h3>
                <div class="lottery-winning-table">
                  <table>
                    <thead>
                      <tr>
                        <th class="name">lottery</th>
                        <th class="date">draw date</th>
                        <th class="numbers">winning numbers</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><div class="winner-details"><img src="assets/images/flag/1.jpg" alt="flag"><span class="winner-name">cancer charity</span></div></td>
                        <td><span class="winning-date">14/07/2023</span></td>
                        <td>
                          <ul class="number-list">
                            <li>19</li>
                            <li>31</li>
                            <li>21</li>
                            <li class="active">69</li>
                            <li>4</li>
                            
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <td><div class="winner-details"><img src="assets/images/flag/2.jpg" alt="flag"><span class="winner-name">US Powerball</span></div></td>
                        <td><span class="winning-date">14/07/2023</span></td>
                        <td>
                          <ul class="number-list">
                            <li>10</li>
                            <li>11</li>
                            <li>19</li>
                            <li class="active">53</li>
                            <li>99</li>
                            <li class="active">54</li>
                            <li>6</li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <td><div class="winner-details"><img src="assets/images/flag/3.jpg" alt="flag"><span class="winner-name">Mega Millions</span></div></td>
                        <td><span class="winning-date">14/07/2023</span></td>
                        <td>
                          <ul class="number-list">
                            <li>19</li>
                            <li>21</li>
                            <li class="active">31</li>
                            <li class="active">59</li>
                            <li>27</li>
                            <li class="active">77</li>
                            <li>66</li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <td><div class="winner-details"><img src="assets/images/flag/1.jpg" alt="flag"><span class="winner-name">UK Lotto</span></div></td>
                        <td><span class="winning-date">14/07/2023</span></td>
                        <td>
                          <ul class="number-list">
                            <li>19</li>
                            <li>31</li>
                            <li>21</li>
                            <li class="active">69</li>
                            <li>99</li>
                            <li>77</li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <td><div class="winner-details"><img src="assets/images/flag/3.jpg" alt="flag"><span class="winner-name">Mega Millions</span></div></td>
                        <td><span class="winning-date">14/07/2023</span></td>
                        <td>
                           <ul class="number-list">
                  <li>11</li>
                  <li>1</li>
                  <li class="active">3</li>
                  <li>26</li>
                  <li>60</li>
                  <li>31</li>
                </ul>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div> 
          </div>
          <div class="col-lg-4">
            <div class="winner-part">
              <h3 class="block-title">our winners</h3>
              <div class="winner-list">
                              <div class="winner-single">
                  <div class="winner-header"><img src="assets/images/flag/1.jpg" alt="flag"><span class="name">Vola Pitmar</span></div>
                  <p><span class="lottery-name">Cancer Charity</span><span class="date">14/07/2023</span></p>
                  <h5 class="prize-amount">$50,000,000</h5>
                </div>
                                <div class="winner-single">
                  <div class="winner-header"><img src="assets/images/flag/4.jpg" alt="flag"><span class="name">Cay Colon</span></div>
                  <p><span class="lottery-name">Powerball</span><span class="date">14/07/2023</span></p>
                  <h5 class="prize-amount">$19,000,000</h5>
                </div>
                                <div class="winner-single">
                  <div class="winner-header"><img src="assets/images/flag/5.jpg" alt="flag"><span class="name">Irez Newtkon</span></div>
                  <p><span class="lottery-name">Mega Millions</span><span class="date">26/06/2023</span></p>
                  <h5 class="prize-amount">$14/07/2023</h5>
                </div>
                    
                <!-- winner-single end -->
                <!-- <div class="winner-single">
                  <div class="winner-header"><img src="assets/images/flag/4.jpg" alt="flag"><span class="name">cay colon</span></div>
                  <p><span class="lottery-name">Powerball</span><span class="date">30/05/2018</span></p>
                  <h5 class="prize-amount">€340.00</h5>
                </div> -->
                <!-- winner-single end -->
                <!-- <div class="winner-single">
                  <div class="winner-header"><img src="assets/images/flag/5.jpg" alt="flag"><span class="name">irez newtkon</span></div>
                  <p><span class="lottery-name">Powerball</span><span class="date">30/05/2018</span></p>
                  <h5 class="prize-amount">€130.00</h5>
                </div> -->
                <!-- winner-single end -->
              </div>
            </div>
          </div>
          <div class="col-lg-12 text-center">
            <a href="lottery-result" class="text-btn">see all result</a>
          </div>
        </div>
      </div>
    </section>    <!-- lottery-result-section end -->

    <!-- choose-us-section start -->
    <section class="choose-us-section section-padding">
      <div class="choose-us-image"><img src="assets/images/elements/mouse.png" alt="image"></div>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="section-header text-center">
              <h2 class="section-title">Why Choose Us?</h2>
              <p>Global Express Lotto makes playing the world's largest lotteries easy and fun.</p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-9">
            <div class="row mt-mb-15">
              <div class="col-lg-4 col-sm-6">
                <div class="choose-item text-center">
                  <div class="front">
                    <div class="icon">
                      <img src="assets/images/svg-icons/choose-us-icons/1.svg" alt="icon">
                    </div>
                    <h4 class="title">Biggest lottery jackpots</h4>
                  </div>
                  <div class="back">
                    <p>One of the core advantages of playing an online lotto is that it is both safe and secure. So, there is no need for you to queue, or visit a retail store, to get tickets.</p>
                  </div>
                </div>
              </div><!-- choose-item end -->
              <div class="col-lg-4 col-sm-6">
                <div class="choose-item text-center">
                  <div class="front">
                    <div class="icon">
                    <img src="assets/images/svg-icons/choose-us-icons/3.svg" alt="icon">
                    </div>
                    <h4 class="title"> Safe and Secure Playing</h4>
                  </div>
                  <div class="back">
                  <p>We are safe and secure with a vast number of online players globally, we are trusted and reliable.
Global premier lottery® respects absolutely the privacy of every person visiting our website...</p>
                  </div>
                </div>
              </div><!-- choose-item end -->
              <div class="col-lg-4 col-sm-6">
                <div class="choose-item text-center">
                  <div class="front">
                    <div class="icon">
                    <img src="assets/images/svg-icons/choose-us-icons/4.svg" alt="icon">
                    </div>
                    <h4 class="title"> Instant payout system</h4>
                  </div>
                  <div class="back">
                    <p>Our payment system is fast regardless your financial institution and you can receive your money safely from any part of the world safely... </p>
                  </div>
                </div>
              </div><!-- choose-item end -->
              <!-- <div class="col-lg-4 col-sm-6">
                <div class="choose-item text-center">
                  <div class="front">
                    <div class="icon">
                      <img src="assets/images/svg-icons/choose-us-icons/4.svg" alt="icon">
                    </div>
                    <h4 class="title">Instant payout system</h4>
                  </div>
                  <div class="back">
                    <p>Our payment system is fast regardless your financial institution and you can receive your money safely from any part of the world safely... </p>
                  </div>
                </div>
              </div> -->
              <!-- choose-item end -->
              <!-- <div class="col-lg-4 col-sm-6">
                <div class="choose-item text-center">
                  <div class="front">
                    <div class="icon">
                      <img src="assets/images/svg-icons/choose-us-icons/5.svg" alt="icon">
                    </div>
                    <h4 class="title">Performance Bonuses</h4>
                  </div>
                  <div class="back">
                    <p>One of the core advantages of playing an online lotto is that it is both safe and secure. So, there is no need for you to queue, or visit a retail store, to get tickets.</p>
                  </div>
                </div>
              </div> -->
              <!-- choose-item end -->
              <!-- <div class="col-lg-4 col-sm-6">
                <div class="choose-item text-center">
                  <div class="front">
                    <div class="icon">
                      <img src="assets/images/svg-icons/choose-us-icons/6.svg" alt="icon">
                    </div>
                    <h4 class="title">Dedicated Support</h4>
                  </div>
                  <div class="back">
                    <p>One of the core advantages of playing an online lotto is that it is both safe and secure. So, there is no need for you to queue, or visit a retail store, to get tickets.</p>
                  </div>
                </div>
              </div> -->
              
              
              <!-- choose-item end -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- choose-us-section end -->

    <!-- work-steps-section strat -->
    <section class="work-steps-section section-padding border-top">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-7">
            <div class="section-header text-center">
              <h2 class="section-title">how it works</h2>
              <p>Global Express Lotto is the best way to play these exciting lotteries from anywhere in the world.</p>
            </div>
          </div>
        </div>
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="work-steps-items-part d-flex">
              <div class="line"><img src="assets/images/elements/line.png" alt="line-image"></div>
              <div class="work-steps-item">
                <div class="work-steps-item-inner">
                  <div class="icon"><img src="assets/images/svg-icons/how-work-icons/1.svg" alt="icon">
                    <span class="count-num">01</span></div>
                  <h4 class="title">choose</h4>
                  <p>Choose your lottery & pick your numbers</p>
                </div>
              </div><!-- work-steps-item end -->
              <div class="work-steps-item">
                <div class="work-steps-item-inner">
                  <div class="icon"><img src="assets/images/svg-icons/how-work-icons/2.svg" alt="icon">
                    <span class="count-num">02</span></div>
                  <h4 class="title">buy</h4>
                  <p>Complete your purchase</p>
                </div>
              </div><!-- work-steps-item end -->
              <div class="work-steps-item">
                <div class="work-steps-item-inner">
                  <div class="icon"><img src="assets/images/svg-icons/how-work-icons/3.svg" alt="icon">
                    <span class="count-num">01</span></div>
                  <h4 class="title">win</h4>
                  <p>Start dreaming, you're almost there</p>
                </div>
              </div><!-- work-steps-item end -->
            </div>
          </div>
          <div class="col-lg-6">
            <div class="work-steps-thumb-part">
              <img src="assets/images/elements/step.png" alt="work-step-image">
              <!-- <a href="https://www.youtube.com/embed/aFYlAzQHnY4" data-rel="lightcase:myCollection" class="play-btn"><i class="fa fa-play"></i></a> -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- work-steps-section strat -->

    <!-- online-ticket-section start -->
      <section class="online-ticket-section section-padding has_bg_image" data-background="assets/images/bg-two.jpg">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-header text-center">
              <h2 class="section-title">Buy Lottery Tickets Online</h2>
              <p>Play the lottery online safely and securely at Global Premier Lottery, the leading lottery ticket purchasing service in the world</p>
            </div>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-lg-10">
            <div class="online-ticket-table-part">
              <div class="online-ticket-table">
                <h3 class="block-title">Place a bet!</h3>
                <div class="online-ticket-table-wrapper">
                  <table>
                    <thead>
                      <tr>
                        <th class="name">lottery</th>
                        <th class="jackpot">jackpot</th>
                        <th class="price">price</th>
                        
                        <th class="sold-num">sold</th>
                        <th class="status">time to draw</th>
                         <th class="draw-time"></th> 
                        
                      </tr>
                    </thead>
                    <tbody>
                                          <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/1.jpg" alt="flag"><span class="winner-name">Euro Jackpots</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">$ 35,442,000</span>
                        </td>
                        <td>
                          <span class="price">$70</span>
                        </td>
                        <!-- <td>
                          <div class="draw-timer"></div>
                        </td> -->
                        <td>
                          <div class="progressbar" data-perc="20%">
                            <div class="bar"></div>
                            <span class="label">20</span>
                          </div>
                        </td>
<td>
                        <div style="color:#33b5f7;" id="clock1">clock1</div>
                        
                        <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vaafb692b2aea4879b33c060e79fe94621666317369993" integrity="sha512-0ahDYl866UMhKuYcW078ScMalXqtFJggm7TmlUtp0UlD4eQk0Ixfnm5ykXKvGJNFjLMoortdseTfsRT8oCfgGA==" data-cf-beacon='{"rayId":"7994e3ff2b2f8cba","version":"2023.2.0","r":1,"token":"b930e9beda8c41ca92a77c802cce6368","si":100}' crossorigin="anonymous"></script>
                        </td>
                        <td>
                          <form method="GET">
                          <!-- <a  name="btn_alert" class="cmn-btn">buy ticket</a> -->
                          <input type='submit' name='btn_alert' class='cmn-btn' value='buy ticket'>									
                          
                          
                          <!--<input type="submit" name="btn_alert" class="cmn-btn" value="buy ticket">-->
            </form>
                        </td>
                        
                      </tr>

                                            <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/1.jpg" alt="flag"><span class="winner-name">Cancer Charity</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">$ 13,287,000</span>
                        </td>
                        <td>
                          <span class="price">$50</span>
                        </td>
                        <!-- <td>
                          <div class="draw-timer"></div>
                        </td> -->
                        <td>
                          <div class="progressbar" data-perc="90%">
                            <div class="bar"></div>
                            <span class="label">90</span>
                          </div>
                        </td>
<td>
                        <div style="color:#33b5f7;" id="clock2">clock2</div>
                        
                        <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vaafb692b2aea4879b33c060e79fe94621666317369993" integrity="sha512-0ahDYl866UMhKuYcW078ScMalXqtFJggm7TmlUtp0UlD4eQk0Ixfnm5ykXKvGJNFjLMoortdseTfsRT8oCfgGA==" data-cf-beacon='{"rayId":"7994e3ff2b2f8cba","version":"2023.2.0","r":1,"token":"b930e9beda8c41ca92a77c802cce6368","si":100}' crossorigin="anonymous"></script>
                        </td>
                        <td>
                          <form method="GET">
                          <!-- <a  name="btn_alert" class="cmn-btn">buy ticket</a> -->
                          <input type='submit' name='btn_alert' class='cmn-btn' value='buy ticket'>									
                          
                          
                          <!--<input type="submit" name="btn_alert" class="cmn-btn" value="buy ticket">-->
            </form>
                        </td>
                        
                      </tr>

                                            <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/6.png" alt="flag"><span class="winner-name">US Powerball
</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">$ 161,557,581</span>
                        </td>
                        <td>
                          <span class="price">$60</span>
                        </td>
                        <!-- <td>
                          <div class="draw-timer"></div>
                        </td> -->
                        <td>
                          <div class="progressbar" data-perc="30%">
                            <div class="bar"></div>
                            <span class="label">30</span>
                          </div>
                        </td>
<td>
                        <div style="color:#33b5f7;" id="clock3">clock3</div>
                        
                        <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vaafb692b2aea4879b33c060e79fe94621666317369993" integrity="sha512-0ahDYl866UMhKuYcW078ScMalXqtFJggm7TmlUtp0UlD4eQk0Ixfnm5ykXKvGJNFjLMoortdseTfsRT8oCfgGA==" data-cf-beacon='{"rayId":"7994e3ff2b2f8cba","version":"2023.2.0","r":1,"token":"b930e9beda8c41ca92a77c802cce6368","si":100}' crossorigin="anonymous"></script>
                        </td>
                        <td>
                          <form method="GET">
                          <!-- <a  name="btn_alert" class="cmn-btn">buy ticket</a> -->
                          <input type='submit' name='btn_alert' class='cmn-btn' value='buy ticket'>									
                          
                          
                          <!--<input type="submit" name="btn_alert" class="cmn-btn" value="buy ticket">-->
            </form>
                        </td>
                        
                      </tr>

                                            <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/6.png" alt="flag"><span class="winner-name">Mega Millions</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">$ 25,000,000</span>
                        </td>
                        <td>
                          <span class="price">$75</span>
                        </td>
                        <!-- <td>
                          <div class="draw-timer"></div>
                        </td> -->
                        <td>
                          <div class="progressbar" data-perc="60%">
                            <div class="bar"></div>
                            <span class="label">60</span>
                          </div>
                        </td>
<td>
                        <div style="color:#33b5f7;" id="clock4">clock4</div>
                        
                        <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vaafb692b2aea4879b33c060e79fe94621666317369993" integrity="sha512-0ahDYl866UMhKuYcW078ScMalXqtFJggm7TmlUtp0UlD4eQk0Ixfnm5ykXKvGJNFjLMoortdseTfsRT8oCfgGA==" data-cf-beacon='{"rayId":"7994e3ff2b2f8cba","version":"2023.2.0","r":1,"token":"b930e9beda8c41ca92a77c802cce6368","si":100}' crossorigin="anonymous"></script>
                        </td>
                        <td>
                          <form method="GET">
                          <!-- <a  name="btn_alert" class="cmn-btn">buy ticket</a> -->
                          <input type='submit' name='btn_alert' class='cmn-btn' value='buy ticket'>									
                          
                          
                          <!--<input type="submit" name="btn_alert" class="cmn-btn" value="buy ticket">-->
            </form>
                        </td>
                        
                      </tr>

                         
                      <!-- <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/2.jpg" alt="flag"><span class="winner-name">US Powerball</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">€ 53,000,000</span>
                        </td>
                        <td>
                          <span class="price">€3.9</span>
                        </td>
                        <td>
                          <div class="draw-timer"></div>
                        </td>
                        <td>
                          <div class="progressbar" data-perc="50%">
                            <div class="bar"></div>
                            <span class="label">50</span>
                          </div>
                        </td>
                        <td>
                          <a href="#" class="cmn-btn">buy ticket</a>
                        </td>
                      </tr> -->
                      <!-- <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/3.jpg" alt="flag"><span class="winner-name">Mega Millions</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">€ 53,000,000</span>
                        </td>
                        <td>
                          <span class="price">€3.9</span>
                        </td>
                        <td>
                          <div class="draw-timer"></div>
                        </td>
                        <td>
                          <div class="progressbar" data-perc="50%">
                            <div class="bar"></div>
                            <span class="label">50</span>
                          </div>
                        </td>
                        <td>
                          <a href="#" class="cmn-btn">buy ticket</a>
                        </td>
                      </tr> -->
                      <!-- <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/1.jpg" alt="flag"><span class="winner-name">UK Lotto</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">€ 53,000,000</span>
                        </td>
                        <td>
                          <span class="price">€3.9</span>
                        </td>
                        <td>
                          <div class="draw-timer"></div>
                        </td>
                        <td>
                          <div class="progressbar" data-perc="50%">
                            <div class="bar"></div>
                            <span class="label">50</span>
                          </div>
                        </td>
                        <td>
                          <a href="#" class="cmn-btn">buy ticket</a>
                        </td>
                      </tr> -->
                      <!-- <tr>
                        <td>
                          <div class="winner-details"><img src="assets/images/flag/3.jpg" alt="flag"><span class="winner-name">Mega Millions</span></div>
                        </td>
                        <td>
                          <span class="jackpot-price">€ 53,000,000</span>
                        </td>
                        <td>
                          <span class="price">€3.9</span>
                        </td>
                        <td>
                          <div class="draw-timer"></div>
                        </td>
                        <td>
                          <div class="progressbar" data-perc="50%">
                            <div class="bar"></div>
                            <span class="label">50</span>
                          </div>
                        </td>
                        <td>
                          <a href="#" class="cmn-btn">buy ticket</a>
                        </td>
                      </tr> -->
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-12 text-center">
            <a href="lottery" class="text-btn">view all lotteries</a>
          </div>
        </div>
      </div>
    </section>
    <!-- online-ticket-section end -->

    <!-- affiliate-section start -->
   
    <!-- affiliate-section end -->

    <!-- payment-method-section start -->
    <section class="payment-method-section section-padding border-top">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="section-header text-center">
              <h2 class="section-title">Payment Method</h2>
              <p>Buy international lottery tickets online using any of the payment methods available on Global Express Lotto Play now and win big!</p>
            </div>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-lg-10">
            <div class="payment-method-area d-flex">
              <div class="payment-item">
              <img src="assets/images/payment-methods/1.jpg" alt="payment-method-image" style="height:70px; width:190px;">
              </div><!-- payment-item end -->
               <div class="payment-item">
               <img src="assets/images/payment-methods/PayPal.svg%20(1).png" alt="payment-method-image">
              </div> 
              <!-- payment-item end -->
               <div class="payment-item">
                <img src="assets/images/payment-methods/Cash-App-Logo.png" alt="payment-method-image">
              </div> 
              <!-- payment-item end -->
              <!-- <div class="payment-item">
                <a href="#0"><img src="assets/images/payment-methods/4.jpg" alt="payment-method-image"></a>
              </div> -->
              <!-- payment-item end -->
              <!-- <div class="payment-item">
                <a href="#0"><img src="assets/images/payment-methods/5.jpg" alt="payment-method-image"></a>
              </div> -->
              <!-- payment-item end -->
              <!-- <div class="payment-item">
                <a href="#0"><img src="assets/images/payment-methods/6.jpg" alt="payment-method-image"></a>
              </div> -->
              <!-- payment-item end -->
            </div>
          </div>
          
        </div>
      </div>
    </section>
    <!-- payment-method-section end -->

    <!-- active-user-section start -->
    <section class="active-user-section section-padding section-bg border-top">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-header text-center">
              <h2 class="section-title">Our Users Around The World</h2>
              <p>Over the years we have provided millions of players with tickets to lotteries across the globe and enjoyed having more than one million winners</p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div id="vmap">
              <div class="position-1">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
              <div class="position-2">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
              <div class="position-3">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
              <div class="position-4">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
              <div class="position-5">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
              <div class="position-6">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
              <div class="position-7">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
              <div class="position-8">
                <span class="dot"></span>
                <div class="details">
                  <h6 class="name">Gaylen Hylen</h6>
                  <p class="area">From: Argentina</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="active-item text-center">
              <span class="amount">3 M +</span>
              <p>Registered players</p>
            </div>
          </div><!-- active-item end -->
          <div class="col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="active-item text-center">
              <span class="amount">$ 1.9 BN</span>
              <p>Total in placed bets</p>
            </div>
          </div><!-- active-item end -->
          <div class="col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="active-item text-center">
              <span class="amount">$ 550 M</span>
              <p>Total in payouts</p>
            </div>
          </div><!-- active-item end -->
          <div class="col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="active-item text-center">
              <span class="amount">$ 76 M</span>
              <p>Biggest ever payouts</p>
            </div>
          </div><!-- active-item end -->
          <div class="col-lg-12 text-center">
            <a href="test" class="cmn-btn">join with us</a>
          </div>
        </div>
      </div>
    </section>
    <!-- active-user-section end -->

    <!-- testimonial-section start -->
    <section class="testimonial-section section-padding border-top">
      <div class="container">
        <div class="row justify-content-between">
          <div class="col-lg-6">
            <div class="testimonial-content">
              <h5 class="sub-title">What they think about us</h5>
              <h2 class="title">Testimonials</h2>
              <div class="total-ratings">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <span class="ratings-count-num">3.4M Reviews</span>
              </div>
              <p>With over 12 years of experience as the world’s leading online lottery service provider, Global Express Lotto has catered to over a million users. Find out what our members have to say about us! </p>
              <div class="testimonial-slider-arrows d-flex">
                <div class="button-next"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
                <div class="button-prev"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
              </div>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="testimonial-slider swiper-container">
              <div class="swiper-wrapper">
                <div class="swiper-slide">
                  <div class="testimonial-slide">
                    <div class="testimonial-slide-header d-flex">
                      <div class="client-thumb">
                        <img src="assets/images/testimonial/1.png" alt="image">
                      </div>
                      <div class="client-details">
                        <h5 class="name">Albert G.</h5>
                        <div class="ratings">
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <span>5.00</span>
                        </div>
                        <!--<p><span class="place">France</span><span class="date">15th June, 2022</span></p>-->
                      </div>
                    </div>
                    <div class="testimonial-slide-body">
                      <p>I've played with Global Express Lotto for several years and really appreciate the site. All of my wins have been credited to my account. Thanks to the entire team at  Global Express Lotto!"</p>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="testimonial-slide">
                    <div class="testimonial-slide-header d-flex">
                      <div class="client-thumb">
                        <img src="assets/images/testimonial/2.png" alt="image">
                      </div>
                      <div class="client-details">
                        <h5 class="name">Edward L.</h5>
                        <div class="ratings">
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <span>5.00</span>
                        </div>
                        <!--<p><span class="place">France</span><span class="date">15th December, 2021</span></p>-->
                      </div>
                    </div>
                    <div class="testimonial-slide-body">
                      <p>Global premier lottery is the best online lottery platform, i won the powerball and i was paid...thanks</p>
                    </div>
                  </div>
                </div><!--swiper-slide end -->
                <div class="swiper-slide">
                  <div class="testimonial-slide">
                    <div class="testimonial-slide-header d-flex">
                      <div class="client-thumb">
                        <img src="assets/images/testimonial/1.png" alt="image">
                      </div>
                      <div class="client-details">
                        <h5 class="name">Albert G.</h5>
                        <div class="ratings">
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <span>5.00</span>
                        </div>
                        <!--<p><span class="place">France</span><span class="date">15th June, 2018</span></p>-->
                      </div>
                    </div>
                    <div class="testimonial-slide-body">
                      <p>I've played with Global Express Lotto for several years and really appreciate the site. All of my wins have been credited to my account. Thanks to the entire team at  Global Express Lotto!"</p>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="testimonial-slide">
                    <div class="testimonial-slide-header d-flex">
                      <div class="client-thumb">
                        <img src="assets/images/testimonial/2.png" alt="image">
                      </div>
                      <div class="client-details">
                        <h5 class="name">Edward L.</h5>
                        <div class="ratings">
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <span>5.00</span>
                        </div>
                        <!--<p><span class="place">France</span><span class="date">15th June, 2018</span></p>-->
                      </div>
                    </div>
                    <div class="testimonial-slide-body">
                      <p>I've played with Global Express Lotto for several years and really appreciate the site. All of my wins have been credited to my account. Thanks to the entire team at  Global Express Lotto!"</p>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="testimonial-slide">
                    <div class="testimonial-slide-header d-flex">
                      <div class="client-thumb">
                        <img src="assets/images/testimonial/1.png" alt="image">
                      </div>
                      <div class="client-details">
                        <h5 class="name">Albert G.</h5>
                        <div class="ratings">
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <i class="fa fa-star"></i>
                          <span>5.00</span>
                        </div>
                        <!--<p><span class="place">France</span><span class="date">15th June, 2018</span></p>-->
                      </div>
                    </div>
                    <div class="testimonial-slide-body">
                      <p>I've played with Global Express Lotto for several years and really appreciate the site. All of my wins have been credited to my account. Thanks to the entire team at  Global Express Lotto!"</p>
                    </div>
                  </div>
                </div>
              </div>  
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- testimonial-section end -->

    <!-- team-section start -->
    <section class="team-section section-padding section-bg border-top">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-header text-center">
              <h2 class="section-title">Our Management Team</h2>
              <p>Our team of creative programmers, marketing experts, and members of the global lottery community have worked together to build the ultimate lottery site, and every win and happy customer reminds us how lucky we are to be doing what we love.</p>
            </div>
          </div>
        </div>
        <div class="row m-bottom-not-30">
          <div class="col-lg-3 col-sm-6">
            <div class="team-single text-center">
              <div class="thumb">
                <img src="assets/images/team/larry.jpg" alt="team-image">
                <ul class="team-social-link d-flex justify-content-center">
                  <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <div class="content">
                <h3 class="name">Philip Brower</h3>
                <span class="designation">Co-Founder & CEO</span>
              </div>
            </div>
          </div><!-- team-single end -->
          <div class="col-lg-3 col-sm-6">
            <div class="team-single text-center">
              <div class="thumb">
                <img src="assets/images/team/paulson.jpg" alt="team-image">
                <ul class="team-social-link d-flex justify-content-center">
                  <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <div class="content">
                <h3 class="name">Penny Tool</h3>
                <span class="designation">IT Specialist</span>
              </div>
            </div>
          </div><!-- team-single end -->
          <div class="col-lg-3 col-sm-6">
            <div class="team-single text-center">
              <div class="thumb">
                <img src="assets/images/team/smith%20martins.jpg" alt="team-image">
                <ul class="team-social-link d-flex justify-content-center">
                  <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <div class="content">
                <h3 class="name">Conrad Berry</h3>
                <span class="designation">Consultant</span>
              </div>
            </div>
          </div><!-- team-single end -->
          <div class="col-lg-3 col-sm-6">
            <div class="team-single text-center">
              <div class="thumb">
                <img src="assets/images/team/emma%20smith.jpg" alt="team-image">
                <ul class="team-social-link d-flex justify-content-center">
                  <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <div class="content">
                <h3 class="name">Alexis Brady</h3>
                <span class="designation">Financial Adviser</span>
              </div>
            </div>
          </div><!-- team-single end -->
        </div>
      </div>
    </section>
    <!-- team-section end -->

    <!-- contact-section start -->
    <section class="contact-section border-top overflow-hidden has_bg_image" data-background="assets/images/bg-three.jpg">
      <div class="container">
        <div class="row justify-content-between">
          <div class="col-lg-6">
            <div class="section-header text-center">
              <h5 class="top-title">We answer all of your questions</h5>
              <h2 class="section-title text-uppercase">Contact us</h2>
              <p>If you have any questions or queries our helpful support team will be more than happy to assist.</p>
            </div>
            <div class="contact-form-area">
              <form class="contact-form">
                <div class="form-grp">
                  <input type="text" name="contact_name" id="contact_name" placeholder="Full Name">
                </div>
                <div class="form-grp">
                  <input type="email" name="contact_email" id="contact_email" placeholder="Email Address">
                </div>
                <div class="form-grp">
                  <input type="tel" name="contact_phone" id="contact_phone" placeholder="Phone No">
                </div>
                <div class="form-grp">
                  <textarea name="contact_message" id="contact_message" placeholder="Message"></textarea>
                </div>
                <div class="form-grp">
                  <input class="submit-btn" type="submit" value="send message">
                </div>
              </form>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="contact-thumb">
              <img src="assets/images/elements/contact.png" alt="image">
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- contact-section end -->

    <!-- brand-section start -->
    <!-- <div class="brand-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="brand-slider">
              <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/1.png" alt="image">
                </div>
              </div> -->
              <!-- single-slide end -->
              <!-- <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/2.png" alt="image">
                </div>
              </div> -->
              <!-- single-slide end -->
              <!-- <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/3.png" alt="image">
                </div> -->
              <!-- </div> -->
              <!-- single-slide end -->
              <!-- <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/4.png" alt="image">
                </div> -->
              <!-- </div> -->
              <!-- single-slide end -->
              <!-- <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/5.png" alt="image">
                </div>
              </div> -->
              <!-- single-slide end -->
              <!-- <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/3.png" alt="image">
                </div>
              </div> -->
              <!-- single-slide end -->
              <!-- <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/4.png" alt="image">
                </div>
              </div> -->
              <!-- single-slide end -->
              <!-- <div class="single-slide">
                <div class="slide-inner">
                  <img src="assets/images/brand/5.png" alt="image">
                </div>
              </div> -->
              <!-- single-slide end -->
            <!-- </div>
          </div>
        </div>
      </div>
    </div> -->
    <!-- brand-section end -->

    <!-- footer-section start -->
    <footer class="footer-section">
      <div class="footer-top border-top border-bottom has_bg_image" data-background="assets/images/bg-four.jpg">
        <div class="footer-top-first">
          <div class="container">
            <div class="row">
              <div class="col-lg-6 col-md-5 col-sm-4 text-center text-sm-left">
                <a href="/" class="site-logo">
                  <img src="assets/images/Globalpremierlottowebsite.png" style="height:30%; width:60%; alt="logo">
                </a>
              </div>
              <div class="col-lg-6 col-md-7 col-sm-8">
                <div class="number-count-part d-flex">
                  <div class="number-count-item">
                    <span class="number">23,302,233</span>
                    <p>TOTAL MEMBERS</p>
                  </div>
                  <div class="number-count-item">
                    <span class="number">9,017,575</span>
                    <p>TOTAL winner</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-top-second">
          <div class="container">
            <div class="row justify-content-between">
              <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12">
                <div class="footer-widget widget-about">
                  <h3 class="widget-title">About Global Express Lotto</h3>
                  <ul class="footer-list-menu">
                    <li><a href="index-2">Home</a></li>
                    <li><a href="lottery">Lottery</a></li>
                    <li><a href="lottery-result">Results</a></li>
                     <li><a href="latest-winner">Winners</a></li> 
                    <li><a href="about">About</a></li>
                    <li><a href="privacypolicy">Privacy Policy</a></li>
                  </ul>
                </div>
              </div>
              <!-- <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6">
                <div class="footer-widget widget-links">
                  <h3 class="widget-title">Quick links</h3>
                  <ul class="footer-list-menu">
                  <li><a href="#0">Faq</a>
                    <li><a href="#0">Affiliate Program</a></li>
                    <li><a href="#0">Terms & Conditions</a></li>
                    <li><a href="#0">Privacy Policy</a></li>
                     <li><a href="#0">Global Express Lotto Licenses</a></li> 
                  </ul>
                </div>
              </div> -->
              <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <div class="footer-widget widget-subscribe">
                  <h3 class="widget-title">email newsletters</h3>
                  <div class="subscribe-part">
                    <p>Subscribe now and receive weekly newsletter for latest draw and offer news and much more!</p>
                    <form class="subscribe-form">
                      <input type="email" name="subs_email" id="subs_email" placeholder="Email address">
                      <input type="submit" value="subscribe">
                    </form>
                  </div>
                </div>
              </div>
</br></br></br>
              <center><strong><p style="color:red;">You must be 18 or older to order a lottery ticket. Please play responsibly.</br> If you or someone you know has a gambling problem, kindly send an email to <a href = "mailto: admin@globalexpresslotto.com"><span style="color:blue;" class="text-decoration-underline">admin</span>.</a></p></strong></center>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <div class="container">
          <div class="row justify-content-between align-items-center">
            <div class="col-lg-6 col-sm-7">
              <div class="copy-right-text">
                <p>© 2023 <a href="#">Global Express Lotto</a> - All Rights Reserved.</p>
              </div>
            </div>
            <!-- <div class="col-lg-6 col-sm-5">
              <ul class="footer-social-links d-flex justify-content-end">
                <li><a href="#0"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#0"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#0"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#0"><i class="fa fa-instagram"></i></a></li>
              </ul>
            </div> -->
          </div>
        </div>
      </div>
    </footer>    <!-- footer-section end -->
    
  </div>

  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->  
  
  <!-- jquery library js file -->
  <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.html"></script><script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- flipclock js file -->
  <script src="assets/js/flipclock.min.js"></script>
  <!-- countdown js file -->
  <script src="assets/js/jquery.countdown.min.js"></script>
  <!-- slick js file -->
  <script src="assets/js/slick.min.js"></script>
  <!-- swiper js file -->
  <script src="assets/js/swiper.min.js"></script>
  <!-- lightcase js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- vamp js files -->
  <script src="assets/js/jquery.vmap.min.js"></script>
  <script src="assets/js/jquery.vmap.world.js"></script>
  <!-- main script js file -->
  <script src="assets/js/main.js"></script>
  <script>
    var clock = $('.clock').FlipClock(99000 * 24 * 3, {
      clockFace: 'DailyCounter',
      countdown: true
    });
      jQuery(document).ready(function() {
        jQuery('#vmap').vectorMap({
          map: 'world_en',
          color: '#eaedef',
          backgroundColor: '#f7fcff',
          hoverOpacity: 0.8,
          selectedColor: '#eaedef',
          scaleColors: ['#f7fcff', '#f7fcff'],
          normalizeFunction: 'polynomial'
        });
      });
    </script>  
</body>
<script src="timer.js"></script>

<!-- Mirrored from Global Express Lotto.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 27 Sep 2023 13:00:08 GMT -->
</html><?php /**PATH D:\laravel\lottory\resources\views/screen/home.blade.php ENDPATH**/ ?>