

<?php $__env->startSection('content'); ?>

<p class="mb-3" style="font-size:24px; font-weight:600"> <i class="fa fa-user-o"></i> Profile</p>

<div class="row">
    <div class="col-md-5 mb-md-0 mb-4">
        <div class="w-100 h-100 pt-4 shadow-sm text-center bg-white">
            <div style="font-size:100px"> <i class="fa fa-user-circle-o"></i> </div>
            <div style="font-size: 25px; font-weight:600"> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="w-100 mb-3 p-4 shadow-sm bg-white">
            <span>Full Name</span>
            <div class="mb-3" style="font-size: 20px; font-weight: 600"> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> </div>
            <span>Email Address</span>
            <div class="mb-3" style="font-size: 20px; font-weight: 600"> <?php echo e($user->email_address); ?> </div>
            <span>Phone Number</span>
            <div class="mb-3" style="font-size: 20px; font-weight: 600"> <?php echo e($user->phone_number); ?> </div>
            <span>Country</span>
            <div class="mb-3" style="font-size: 20px; font-weight: 600"> <?php echo e($user->country); ?> </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/user/profile.blade.php ENDPATH**/ ?>