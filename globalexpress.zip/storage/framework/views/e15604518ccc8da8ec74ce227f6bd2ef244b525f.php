

<?php $__env->startSection('content'); ?>

<p class="mb-3" style="font-size:24px; font-weight:600"> <i class="fa fa-arrow-down"></i> Withdraw</p>
<?php if(Session::has('successful')): ?>
    <div class="alert alert-success"> <?php echo e(Session::get('successful')); ?> </div>
<?php endif; ?>
<?php if(Session::has('fail')): ?>
    <div class="alert alert-danger"> <?php echo e(Session::get('fail')); ?> </div>
<?php endif; ?>
<form action="<?php echo e(url('user/post-withdraw')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" id="btcCurrentPrice" value="<?php echo e($btcCurrentPrice); ?>">

    <div class="w-100 mt-3">
        <label class="m-0">Amount to Withdraw</label>
        <input required name="amount" id="withdrawAmt" type="number" style="height:50px" class="form-control">
    </div>

    <div class="w-100 mt-3">
        <label class="m-0">Bitcoin Worth</label>
        <input name="bitcoin_worth" id="btc_worth" type="number" readonly value="" style="height:50px" class="form-control">
    </div>

    <div class="w-100 mt-3">
        <label class="m-0">Bitcoin Wallet To Credit</label>
        <input required name="bitcoin_wallet_to_credit" type="text" style="height:50px" class="form-control">
    </div>

    <div class="w-100 mt-3">
        <button class="btn btn-primary"> <i class="fa fa-arrow-down"></i> Withdraw</button>
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/user/withdraw.blade.php ENDPATH**/ ?>