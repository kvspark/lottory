

<?php $__env->startSection('content'); ?>

<h4>All Tickets</h4>

<div class="table-reponsive">
    <table class="table">
        <thead>
            <tr>
                <th>Lottery</th>
                <th>Jackpot</th>
                <th> Price </th>
                <th> Sold </th>
                <th> Time To Draw </th>
                <th> Edit </th>
                <th> Delete </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($ticket->lottory); ?> </td>
                    <td> <?php echo e($ticket->jackpot); ?> </td>
                    <td> <?php echo e($ticket->price); ?> </td>
                    <td> <?php echo e($ticket->sold); ?> </td>
                    <td> <?php echo e($ticket->time_to_draw); ?> </td>
                    <td> <a href="<?php echo e(url('admin/edit-ticket')); ?>/<?php echo e($ticket->id); ?>" class="btn btn-primary"> Edit </a> </td>
                    <td> <a href="<?php echo e(url('admin/delete-ticket')); ?>/<?php echo e($ticket->id); ?>" class="btn btn-danger"> Delete </a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/tickets.blade.php ENDPATH**/ ?>