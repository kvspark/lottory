

<?php $__env->startSection('content'); ?>

<h4> <?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?> Purchase Ticket/Placed Bet </h4>

<div class="responsive-table mt-3">
    <table style="font-size:16px" class="table">
        <thead>
            <tr>
                <th>Rececipt</th>
                <th>Date</th>
                <th>Ref</th>
                <th>Lottery </th>
                <th>Lottery Number</th>
                <th>Jackpot</th>
                <th>Ticket Price</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $member->purchasetickets()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <a href="<?php echo e(url('img/receipt')); ?>/<?php echo e($ticket->receipt); ?>" download> View Receipt </a> </td>
                    <td> <?php echo e($ticket->created_at); ?> </td>
                    <td class="text-uppercase"> <?php echo e($ticket->ref); ?> </td>
                    <td> <?php echo e($ticket->jackpots); ?> </td>
                    <td class="d-flex"> 
                        <?php if(!$ticket->lottery_numbers): ?>
                        <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> 0 </span>
                        <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> 0 </span>
                        <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> 0 </span>
                        <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> 0 </span>
                        <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> 0 </span>
                        <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> 0 </span>
                        <?php else: ?>
                            <?php    
                                $win = $ticket->lottery_numbers;
                                $wins = preg_split('/ /',$win);
                            ?>
                            <?php $__currentLoopData = $wins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="border border-2 rounded rounded-circle border-dark d-flex justify-content-center align-items-center mr-3" style="height: 40px; width: 40px;"> <?php echo e($w); ?> </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                    <td> <?php echo e($ticket->earning); ?> </td>
                    <td> $<?php echo e($ticket->amount); ?> </td>
                    <td> <?php echo e($ticket->payment_method); ?> </td>
                    <td> 
                        <?php if($ticket->status == "Pending"): ?>    
                            <span class="btn btn-warning"><?php echo e($ticket->status); ?></span> </td>
                        <?php elseif($ticket->status == "Decline"): ?>
                            <span class="btn btn-danger"><?php echo e($ticket->status); ?></span> </td>
                        <?php elseif($ticket->status == "Approved"): ?>
                            <span class="btn btn-secondary"><?php echo e($ticket->status); ?></span> </td>
                        <?php elseif($ticket->status == "Lose"): ?>
                            <span class="btn btn-danger"><?php echo e($ticket->status); ?></span> </td>
                        <?php elseif($ticket->status == "Win"): ?>
                            <span class="btn btn-success"><?php echo e($ticket->status); ?></span> </td>
                        <?php endif; ?>
                    </td>
                    <td> <a href="<?php echo e(url('admin/edit-bet/' . $ticket->id)); ?>" class="btn btn-primary"> Edit </a> </td>
                    <td> <a href="<?php echo e(url('admin/delete-bet/' . $ticket->id)); ?>" class="btn btn-danger"> Delete </a> </td>    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/placed-bet.blade.php ENDPATH**/ ?>