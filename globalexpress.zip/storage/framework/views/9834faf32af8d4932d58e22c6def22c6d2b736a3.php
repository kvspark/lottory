

<?php $__env->startSection('content'); ?>

<h4> Edit Bets </h4>
<?php if(Session::has('successful')): ?>
    <div class="alert alert-success"> <?php echo e(Session::get('successful')); ?> </div>
<?php endif; ?>
<div class="mt-3">
    <form action="<?php echo e(url('admin/post-edit-bet')); ?>/<?php echo e($purchaseticket->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label class="mb-0">Date</label>
        <input type="text" value="<?php echo e($purchaseticket->created_at); ?>" name="date" style="height: 50px;" class="form-control mb-3 shadow-none">
        <label class="mb-0">Status</label>
        <select name="status" style="height: 50px;" class="form-control mb-3 shadow-none">
            <option> <?php echo e($purchaseticket->status); ?> </option>
            <option>Pending</option>
            <option>Decline</option>
            <option>Approved</option>
            <option>Win</option>
            <option>Lose</option>
        </select>
        <button class="btn btn-primary" style="height: 50px;">Update Bet</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\lottory\resources\views/admin/edit-bet.blade.php ENDPATH**/ ?>